<?php
declare(strict_types=1);

// PARENT (abstract): semua data & validasi umum ada di sini, tidak diulang di child.
abstract class Mahasiswa {
    private string $nim;
    private string $nama;
    private string $fakultas;
    private string $prodi;
    private string $asalSekolah;
    private int $semester;
    private string $hobi;
    private string $agama;
    private string $alamat;
    private string $golonganDarah;

    public function __construct(
        string $nim, string $nama, string $fakultas, string $prodi,
        string $asalSekolah, int $semester, string $hobi,
        string $agama, string $alamat, string $golonganDarah
    ) {
        foreach ([
            'NIM' => $nim, 'Nama' => $nama, 'Fakultas' => $fakultas,
            'Prodi' => $prodi, 'Asal sekolah' => $asalSekolah, 'Agama' => $agama,
        ] as $label => $v) {
            if (trim($v) === '') throw new InvalidArgumentException($label . ' wajib diisi');
        }
        if ($semester < 1 || $semester > 14) {
            throw new InvalidArgumentException('Semester harus 1–14');
        }
        $this->nim = trim($nim);
        $this->nama = trim($nama);
        $this->fakultas = trim($fakultas);
        $this->prodi = trim($prodi);
        $this->asalSekolah = trim($asalSekolah);
        $this->semester = $semester;
        $this->hobi = trim($hobi);
        $this->agama = trim($agama);
        $this->alamat = trim($alamat);
        $this->golonganDarah = trim($golonganDarah);
    }

    public function getNim(): string { return $this->nim; }
    public function getNama(): string { return $this->nama; }
    public function getFakultas(): string { return $this->fakultas; }
    public function getProdi(): string { return $this->prodi; }
    public function getAsalSekolah(): string { return $this->asalSekolah; }
    public function getSemester(): int { return $this->semester; }
    public function getHobi(): string { return $this->hobi; }
    public function getAgama(): string { return $this->agama; }
    public function getAlamat(): string { return $this->alamat; }
    public function getGolonganDarah(): string { return $this->golonganDarah; }

    abstract public function getUkt(): int;
    abstract public function getPotonganPersen(): int;
    abstract public function hitungBiaya(): int;
    abstract public function getJenis(): string;
}
