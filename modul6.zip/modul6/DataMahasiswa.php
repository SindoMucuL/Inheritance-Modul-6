<?php
declare(strict_types=1);
require_once __DIR__ . '/MahasiswaReguler.php';
require_once __DIR__ . '/MahasiswaBeasiswa.php';

class DataMahasiswa {
    /** @var array<string, Mahasiswa> */
    private array $data = [];

    public function __construct(array $awal = []) {
        foreach ($awal as $m) {
            if ($m instanceof Mahasiswa) $this->data[$m->getNim()] = $m;
        }
    }
    public function tambah(Mahasiswa $m): bool {
        if (isset($this->data[$m->getNim()])) return false;
        $this->data[$m->getNim()] = $m;
        return true;
    }
    public function cari(string $nim): ?Mahasiswa { return $this->data[$nim] ?? null; }

    /** @return array<string, Mahasiswa> */
    public function semua(): array { return $this->data; }

    /** @return array<string, Mahasiswa> pencarian berdasarkan NIM atau nama */
    public function cariKata(string $kata): array {
        $kata = mb_strtolower(trim($kata));
        if ($kata === '') return $this->data;
        return array_filter($this->data, fn(Mahasiswa $m) =>
            str_contains(mb_strtolower($m->getNim()), $kata) ||
            str_contains(mb_strtolower($m->getNama()), $kata));
    }
    // NIM tidak boleh berubah; jenis (Reguler/Beasiswa) boleh berubah.
    public function ubah(string $nimLama, Mahasiswa $m): bool {
        if (!isset($this->data[$nimLama]) || $m->getNim() !== $nimLama) return false;
        $this->data[$nimLama] = $m;
        return true;
    }
    public function hapus(string $nim): bool {
        if (!isset($this->data[$nim])) return false;
        unset($this->data[$nim]);
        return true;
    }
}
