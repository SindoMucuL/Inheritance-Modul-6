<?php
declare(strict_types=1);
require_once __DIR__ . '/DataMahasiswa.php'; // class dimuat sebelum session_start
session_start();

function aman(mixed $v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
// Terima format rupiah: "5.000.000", "Rp 5.000.000" -> "5000000"
function bersihAngka(string $s): string {
    return str_ireplace(['Rp', '.', ' '], '', $s);
}
function formatRp(mixed $n): string {
    $b = bersihAngka((string)$n);
    return preg_match('/^\d+$/', $b) ? number_format((int)$b, 0, ',', '.') : (string)$n;
}
if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));

$repo = new DataMahasiswa($_SESSION['mahasiswa'] ?? []);
$pesan = $_SESSION['flash'] ?? '';
unset($_SESSION['flash']);
$error = '';
$agamaList = ['Islam','Kristen','Katolik','Hindu','Buddha','Konghucu'];
$teks = [ // field teks: nama form => label
    'nim'=>'NIM','nama'=>'Nama','fakultas'=>'Fakultas','prodi'=>'Program Studi',
    'asalSekolah'=>'Asal Sekolah','alamat'=>'Alamat','golonganDarah'=>'Golongan Darah','hobi'=>'Hobi',
];

function nilaiForm(?Mahasiswa $m): array {
    if (!$m) return ['jenis'=>'reguler','semester'=>'','ukt'=>'','potongan'=>'0','agama'=>''] + array_fill_keys(
        ['nim','nama','fakultas','prodi','asalSekolah','alamat','golonganDarah','hobi'], '');
    return [
        'nim'=>$m->getNim(),'nama'=>$m->getNama(),'fakultas'=>$m->getFakultas(),'prodi'=>$m->getProdi(),
        'asalSekolah'=>$m->getAsalSekolah(),'alamat'=>$m->getAlamat(),'golonganDarah'=>$m->getGolonganDarah(),
        'hobi'=>$m->getHobi(),'agama'=>$m->getAgama(),'semester'=>$m->getSemester(),
        'jenis'=>$m instanceof MahasiswaBeasiswa ? 'beasiswa' : 'reguler',
        'ukt'=>$m->getUkt(),'potongan'=>$m->getPotonganPersen(),
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form = array_map(fn($v) => is_string($v) ? trim($v) : '', $_POST);
    try {
        if (!hash_equals($_SESSION['csrf'], (string)($_POST['csrf'] ?? ''))) {
            throw new InvalidArgumentException('Token formulir tidak valid. Muat ulang halaman.');
        }
        $aksi = (string)($_POST['aksi'] ?? 'tambah');

        if ($aksi === 'hapus') {
            if (!$repo->hapus(trim((string)($_POST['nim'] ?? '')))) {
                throw new InvalidArgumentException('NIM tidak ditemukan.');
            }
        } elseif ($aksi === 'tambah' || $aksi === 'ubah') {
            if (!in_array($form['agama'] ?? '', $agamaList, true)) {
                throw new InvalidArgumentException('Pilihan agama tidak valid.');
            }
            $semester = filter_var($form['semester'] ?? null, FILTER_VALIDATE_INT);
            $ukt = filter_var(bersihAngka($form['ukt'] ?? ''), FILTER_VALIDATE_INT);
            if ($semester === false || $ukt === false) {
                throw new InvalidArgumentException('Semester dan UKT harus bilangan bulat.');
            }
            $umum = [
                $form['nim'] ?? '', $form['nama'] ?? '', $form['fakultas'] ?? '', $form['prodi'] ?? '',
                $form['asalSekolah'] ?? '', $semester, $form['hobi'] ?? '',
                $form['agama'], $form['alamat'] ?? '', $form['golonganDarah'] ?? '',
            ];
            $jenis = $form['jenis'] ?? '';
            if ($jenis === 'reguler') {
                $m = new MahasiswaReguler(...[...$umum, $ukt]);
            } elseif ($jenis === 'beasiswa') {
                $potongan = filter_var($form['potongan'] ?? null, FILTER_VALIDATE_INT);
                if ($potongan === false) throw new InvalidArgumentException('Potongan harus bilangan bulat.');
                $m = new MahasiswaBeasiswa(...[...$umum, $ukt, $potongan]);
            } else {
                throw new InvalidArgumentException('Jenis mahasiswa tidak dikenal.');
            }
            $ok = $aksi === 'ubah'
                ? $repo->ubah((string)($_POST['nim_lama'] ?? ''), $m)
                : $repo->tambah($m);
            if (!$ok) throw new InvalidArgumentException('NIM duplikat, atau NIM saat edit diubah/tidak ditemukan.');
        } else {
            throw new InvalidArgumentException('Aksi tidak dikenal.');
        }
        $_SESSION['mahasiswa'] = $repo->semua();
        $_SESSION['flash'] = 'Data berhasil ' . ['hapus'=>'dihapus','ubah'=>'diubah','tambah'=>'ditambahkan'][$aksi] . '.';
        header('Location: index.php');
        exit;
    } catch (InvalidArgumentException $e) {
        $error = $e->getMessage();
    }
}

$edit = $repo->cari((string)($_GET['edit'] ?? ''));
// Jika POST gagal, tampilkan kembali isian terakhir agar tidak mengetik ulang.
$v = ($error !== '' && isset($form)) ? $form + nilaiForm(null) : nilaiForm($edit);
$modeEdit = $edit !== null || (($form['aksi'] ?? '') === 'ubah');
$nimLama = $edit ? $edit->getNim() : (string)($_POST['nim_lama'] ?? '');
$q = trim((string)($_GET['q'] ?? ''));
$daftar = $repo->cariKata($q);
?>
<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Praktikum PBO 6 - CRUD Mahasiswa (Inheritance)</title>
<style>
*{box-sizing:border-box}body{font-family:system-ui,Arial,sans-serif;background:#f1f5f9;color:#15324d;margin:0}
main{max-width:1180px;margin:36px auto;padding:0 18px}.muted{color:#60758a}
.panel{background:#fff;border-radius:13px;padding:24px;margin:20px 0;box-shadow:0 5px 18px #16324d14}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px}
label{font-weight:650;font-size:13px;display:block}
input,select{display:block;width:100%;padding:11px;margin-top:6px;border:1px solid #c8d5e3;border-radius:7px;background:#fff;font:inherit}
input[readonly]{background:#eef2f6}
button,.btn{border:0;border-radius:7px;background:#176397;color:#fff;padding:9px 15px;cursor:pointer;text-decoration:none;display:inline-block;font-size:13px}
.danger{background:#b9414a}.actions{display:flex;gap:7px;align-items:center}.actions form{margin:0}
table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:12px 9px;text-align:left;border-bottom:1px solid #e1e8f0}th{background:#e8f1f8}
.scroll{overflow-x:auto}.notice{padding:12px;border-radius:8px;background:#e3f4e9}.err{background:#ffe8e8}
.search{display:flex;gap:8px;margin-bottom:12px}.search input{margin:0}
@media(max-width:650px){.grid{grid-template-columns:1fr}}
</style></head>
<body><main>
<h1>Data Mahasiswa</h1>
<p class="muted">PBO Pertemuan 6: Inheritance (Mahasiswa → Reguler / Beasiswa) + CRUD Session</p>
<?php if ($pesan): ?><div class="notice"><?= aman($pesan) ?></div><?php endif; ?>
<?php if ($error): ?><div class="notice err"><?= aman($error) ?></div><?php endif; ?>

<section class="panel"><h2><?= $modeEdit ? 'Edit' : 'Tambah' ?> Data Mahasiswa</h2>
<form method="post">
<input type="hidden" name="csrf" value="<?= aman($_SESSION['csrf']) ?>">
<input type="hidden" name="aksi" value="<?= $modeEdit ? 'ubah' : 'tambah' ?>">
<input type="hidden" name="nim_lama" value="<?= aman($nimLama) ?>">
<div class="grid">
<?php foreach ($teks as $k => $label): ?>
<label><?= aman($label) ?>
<input type="text" name="<?= aman($k) ?>" value="<?= aman($v[$k]) ?>"
 <?= $k === 'nim' && $modeEdit ? 'readonly' : '' ?> <?= $k === 'hobi' || $k === 'alamat' || $k === 'golonganDarah' ? '' : 'required' ?>></label>
<?php endforeach; ?>
<label>Semester<input type="number" name="semester" min="1" max="14" value="<?= aman($v['semester']) ?>" required></label>
<label>Agama<select name="agama" required><option value="">-- Pilih Agama --</option>
<?php foreach ($agamaList as $a): ?><option value="<?= aman($a) ?>" <?= $v['agama'] === $a ? 'selected' : '' ?>><?= aman($a) ?></option><?php endforeach; ?>
</select></label>
<label>Jenis Mahasiswa<select name="jenis" id="jenis">
<option value="reguler" <?= $v['jenis'] === 'reguler' ? 'selected' : '' ?>>Reguler</option>
<option value="beasiswa" <?= $v['jenis'] === 'beasiswa' ? 'selected' : '' ?>>Beasiswa</option></select></label>
<label>UKT (Rp)<input type="text" inputmode="numeric" id="ukt" name="ukt" placeholder="contoh: 5.000.000" value="<?= aman(formatRp($v['ukt'])) ?>" required></label>
<label id="boxPotongan">Potongan Beasiswa (%)<input type="number" name="potongan" min="0" max="100" value="<?= aman($v['potongan'] === '' ? 0 : $v['potongan']) ?>"></label>
</div>
<p><button><?= $modeEdit ? 'Simpan Perubahan' : 'Tambah Mahasiswa' ?></button>
<?php if ($modeEdit): ?><a class="btn" href="index.php">Batal</a><?php endif; ?></p>
</form></section>

<section class="panel"><h2>Daftar Mahasiswa (<?= count($daftar) ?>)</h2>
<form class="search" method="get"><input name="q" placeholder="Cari NIM / nama" value="<?= aman($q) ?>"><button>Cari</button>
<?php if ($q !== ''): ?><a class="btn" href="index.php">Reset</a><?php endif; ?></form>
<div class="scroll"><table>
<thead><tr><th>NIM</th><th>Nama</th><th>Jenis</th><th>Fakultas</th><th>Prodi</th><th>Smt</th>
<th>UKT</th><th>Potongan</th><th>Biaya Akhir</th><th>Aksi</th></tr></thead>
<tbody>
<?php foreach ($daftar as $m): ?>
<tr>
<td><?= aman($m->getNim()) ?></td><td><?= aman($m->getNama()) ?></td><td><?= aman($m->getJenis()) ?></td>
<td><?= aman($m->getFakultas()) ?></td><td><?= aman($m->getProdi()) ?></td><td><?= aman($m->getSemester()) ?></td>
<td>Rp<?= aman(number_format($m->getUkt(), 0, ',', '.')) ?></td>
<td><?= aman($m->getPotonganPersen()) ?>%</td>
<td><strong>Rp<?= aman(number_format($m->hitungBiaya(), 0, ',', '.')) ?></strong></td>
<td><div class="actions">
<a class="btn" href="?edit=<?= urlencode($m->getNim()) ?>">Edit</a>
<form method="post" onsubmit="return confirm('Hapus data ini?')">
<input type="hidden" name="csrf" value="<?= aman($_SESSION['csrf']) ?>">
<input type="hidden" name="aksi" value="hapus"><input type="hidden" name="nim" value="<?= aman($m->getNim()) ?>">
<button class="danger">Hapus</button></form></div></td>
</tr>
<?php endforeach; ?>
<?php if (!$daftar): ?><tr><td colspan="10">Belum ada data.</td></tr><?php endif; ?>
</tbody></table></div>
<p><small class="muted">Data disimpan pada PHP Session (sementara), bukan MySQL. Angka biaya hanya simulasi praktikum.</small></p></section>
</main>
<script>
const j=document.getElementById('jenis'),b=document.getElementById('boxPotongan');
function t(){b.style.display=j.value==='beasiswa'?'block':'none'}
j.addEventListener('change',t);t();
const u=document.getElementById('ukt');
u.addEventListener('input',()=>{const d=u.value.replace(/\D/g,'');u.value=d?Number(d).toLocaleString('id-ID'):'';});
</script>
</body></html>